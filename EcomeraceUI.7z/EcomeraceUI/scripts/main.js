document.addEventListener('DOMContentLoaded', () => {
    const productsContainer = document.getElementById('products');
    const brandFilter = document.getElementById('brand-filter');
    const priceFilter = document.getElementById('price-filter');
    const priceValue = document.getElementById('price-value');
  
    fetch('data/products.json')
      .then(response => response.json())
      .then(products => {
        displayProducts(products);
        popularBrandFilter(products);
      });
  
    function displayProducts(products) {
      productsContainer.innerHTML = '';
      products.forEach(product => {
        const productElement = document.createElement('div');
        productElement.classList.add('product');
        productElement.innerHTML = `
          <img src="${product.image}" alt="${product.name}">
          <h3>${product.name}</h3>
          <p>${product.description}</p>
          <p>$${product.price}</p>
          <button data-id="${product.id}">Add to Cart</button>
        `;
        productsContainer.appendChild(productElement);
      });
    }
  
    function popularBrandFilter(products) {
      const brands = [...new Set(products.map(product => product.brand))];
      brands.forEach(brand => {
        const option = document.createElement('option');
        option.value = brand;
        option.textContent = brand;
        brandFilter.appendChild(option);
      });
    }
  
    brandFilter.addEventListener('change', filterProducts);
    priceFilter.addEventListener('input', () => {
      priceValue.textContent = priceFilter.value;
      filterProducts();
    });
  
    function filterProducts() {
      const selectedBrand = brandFilter.value;
      const maxPrice = priceFilter.value;
  
      fetch('data/products.json')
        .then(response => response.json())
        .then(products => {
          let filteredProducts = products;
  
          if (selectedBrand) {
            filteredProducts = filteredProducts.filter(product => product.brand === selectedBrand);
          }
  
          filteredProducts = filteredProducts.filter(product => product.price <= maxPrice);
  
          displayProducts(filteredProducts);
        });
    }
  
    productsContainer.addEventListener('click', (event) => {
      if (event.target.tagName === 'BUTTON') {
        const productId = event.target.dataset.id;
        addToCart(productId);
      }
    });
  
    function addToCart(productId) {
      const cart = JSON.parse(localStorage.getItem('cart')) || [];
      const existingProduct = cart.find(product => product.id == productId);
  
      if (existingProduct) {
        existingProduct.quantity += 1;
      } else {
        cart.push({ id: productId, quantity: 1 });
      }
  
      localStorage.setItem('cart', JSON.stringify(cart));
      alert('Product added to cart');
    }
  });
  