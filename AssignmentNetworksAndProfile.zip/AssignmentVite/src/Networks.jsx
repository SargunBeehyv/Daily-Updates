import  { Component } from 'react';
import axios from 'axios';

class Networks extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: {
        name: '',
        email: '',
        phone: ''
      },
      loading: true,
      error: null,
      message: ''
    };
  }

  componentDidMount() {
    axios.get('https://run.mocky.io/v3/a2eebe62-c28f-478d-a8e3-523e589eb31f')
      .then(response => {
        this.setState({ user: response.data, loading: false });
      })
      .catch(error => {
        this.setState({ error: error.message, loading: false });
      });
  }

  handleChange = (event) => {
    const { name, value } = event.target;
    this.setState((prevState) => ({
      user: {
        ...prevState.user,
        [name]: value
      }
    }));
  }

  handleSubmit = (event) => {
    event.preventDefault();
    axios.post('https://run.mocky.io/v3/a2eebe62-c28f-478d-a8e3-523e589eb31f', this.state.user)
      
  }

  render() {
    const { user, loading, error, message } = this.state;

    if (loading) {
      return <div>Loading...</div>;
    }

    if (error) {
      return <div>Error: {error}</div>;
    }

    return (
      <div>
        <h2>User Profile</h2>
        {message && <div>{message}</div>}
        <form onSubmit={this.handleSubmit}>
          <div>
            <label>Name:</label>
            <input
              type="text"
              name="name"
              value={user.name}
              onChange={this.handleChange}
            />
          </div>
          <div>
            <label>Email:</label>
            <input
              type="email"
              name="email"
              value={user.email}
              onChange={this.handleChange}
            />
          </div>
          <div>
            <label>Phone:</label>
            <input
              type="text"
              name="phone"
              value={user.phone}
              onChange={this.handleChange}
            />
          </div>
          <button type="submit">Save Info</button>
        </form>
      </div>
    );
  }
}

export default Networks ;
