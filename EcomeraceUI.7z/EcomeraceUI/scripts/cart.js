document.addEventListener('DOMContentLoaded', () => {
    const cartContainer = document.getElementById('cart');
    const clearCartButton = document.getElementById('clear-cart');
    const totalAmount = document.getElementById('total-amount');
  
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
  
    fetch('data/products.json')
      .then(response => response.json())
      .then(products => {
        displayCart(products);
      });
  
    function displayCart(products) {
      cartContainer.innerHTML = '';
      let total = 0;
  
      cart.forEach(cartItem => {
        const product = products.find(product => product.id == cartItem.id);
        const cartItemElement = document.createElement('div');
        cartItemElement.classList.add('cart-item');
        cartItemElement.innerHTML = `       
          <span>${product.name}</span>
          <span>$${product.price}</span>
          <input type="number" value="${cartItem.quantity}" min="1" data-id="${cartItem.id}">
          <button data-id="${cartItem.id}">Remove</button>
        `;
  
        total += product.price * cartItem.quantity;
        cartContainer.appendChild(cartItemElement);
      });
  
      totalAmount.textContent = `$${total}`;
  
      cartContainer.addEventListener('input', (event) => {
        if (event.target.tagName === 'INPUT') {
          const productId = event.target.dataset.id;
          const newQuantity = parseInt(event.target.value);
          updateQuantity(productId, newQuantity);
        }
      });
  
      cartContainer.addEventListener('click', (event) => {
        if (event.target.tagName === 'BUTTON') {
          const productId = event.target.dataset.id;
          removeFromCart(productId);
        }
      });
    }
  
    function updateQuantity(productId, quantity) {
      const cartItem = cart.find(item => item.id == productId);
      if (cartItem) {
        cartItem.quantity = quantity;
      }
  
      localStorage.setItem('cart', JSON.stringify(cart));
      location.reload();
    }
  
    function removeFromCart(productId) {
      const newCart = cart.filter(item => item.id != productId);
      localStorage.setItem('cart', JSON.stringify(newCart));
      location.reload();
    }
  
    clearCartButton.addEventListener('click', () => {
      localStorage.removeItem('cart');
      location.reload();
    });
  });
  