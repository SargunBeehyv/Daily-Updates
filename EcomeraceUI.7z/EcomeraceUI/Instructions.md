# E-commerce Case Study Assignment

### Objective:

- Create a mini e-commerce application focusing on two main functionalities: visualizing
  products on the homepage and managing a shopping cart. Optionally, implement filters for
  brand and price.

### Instructions:

- Develop a web-based application using HTML, CSS, and JavaScript. The backend can be
  simulated using mock data or a simple JSON file.

* Part 1: Visualizing Products on the Homepage

- Mock Data for Products:
- Create a JSON file or a JavaScript object containing mock data for products. Each product should have the following attributes:

1. id: Unique identifier for the product.
2. name: Name of the product.
3. brand: Brand of the product.
4. price: Price of the product.
5. image: URL of the product image.
6. description: Short description of the product.

Example:

```
[
{
"id": 1,
"name": "Product 1",
"brand": "Brand A",
"price": 100,
"image": "image1.jpg",
"description": "Description of Product 1"
},
{
"id": 2,
"name": "Product 2",
"brand": "Brand B",
"price": 150,
"image": "image2.jpg",
"description": "Description of Product 2"
}
]

```

### Homepage Layout:

- Create a homepage that displays the list of products.
- Each product should be displayed with its image, name, price, and a short description.
- Ensure the products are presented in a user-friendly and visually appealing manner.

1. Interactivity:

- Add a button or a link to each product to allow users to add it to the cart.

2. Part 2: Cart Page

- Adding Products to the Cart:

3. Implement functionality to add products to the cart.

- Store the cart data in the browser’s local storage to persist the cart between page reloads.

4. Cart Layout:

- Create a cart page that lists all the products added to the cart.

5. Display the product name, price, quantity, and total price for each item.

- Provide functionality to update the quantity of each product.
- Include a total amount for all products in the cart.

6. Interactivity:

- Add buttons to remove individual items from the cart.
- Optionally, add a “Clear Cart” button to remove all items from the cart.
- Optional Part: Filters

## Filter by Brand:

- Implement a filter that allows users to view products by selected brands.
- The filter can be a dropdown or a list of checkboxes.
- Filter by Price:
  - Implement a filter to allow users to view products within a specific price range.
  - The filter can be a slider or a range input.
- Evaluation Criteria:
- Code Quality: Clean, well-organized, and commented code.
- Functionality: Correct implementation of required features.
- User Experience: Intuitive and responsive design.
- Optional Features: Extra points for implementing brand and price filters.
