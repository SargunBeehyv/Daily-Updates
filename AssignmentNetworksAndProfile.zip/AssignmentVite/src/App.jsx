import Networks from "./Networks";
import UserProfileForm from "./UserProfileForm";



function App() {


  return (
    <>
    <Networks />
    <UserProfileForm />
    </>

  );
}

export default App
